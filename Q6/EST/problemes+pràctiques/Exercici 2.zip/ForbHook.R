
library(car)

ForbHook = read.csv2("ForbesHooker0.csv")
head(ForbHook)


# Dades Forbes

plot(ForbHook$TForb,ForbHook$PForb)

modelF = lm(PForb~TForb, ForbHook)
summary(modelF)

scatterplot(PForb~TForb, box=F,smooth=F,ForbHook)

# Validar linealitat, varianca constant i valors estranys
plot(predict(modelF),resid(modelF))
abline(h=0,lty=2)
plot(predict(modelF),rstandard(modelF))
abline(h=c(-2,0,2),lty=2)
plot(predict(modelF),rstudent(modelF))
abline(h=c(-2,0,2),lty=2)

plot(rstudent(modelF))
abline(h=c(-2,0,2),lty=2)
text(12,4,"Obs.12")


# Eliminem l'observacio 12, PERQUE SABEM QUE ES UN ERROR.
# Eliminar observacions es pot fer nomes si es te un motiu justificat.
# El fet que una observacio tingui un residu massa gran per si sol no es
# motiu per eliminar-la, perque pot ser culpa del model i no de la observacio.
ForbHook$PForb[12]=NA
ForbHook$TForb[12]=NA
ForbHook

plot(ForbHook$TForb,ForbHook$PForb)

modelFN = lm(PForb~TForb, ForbHook)
summary(modelFN)

scatterplot(PForb~TForb, box=F,smooth=F,ForbHook)

# Validar linealitat, varianca constant i valors estranys
plot(predict(modelFN),rstandard(modelFN))
abline(h=c(-2,0,2),lty=2)



# Dades Hooker

plot(ForbHook$THook,ForbHook$PHook)

modelH = lm(PHook~THook, ForbHook)
summary(modelH)

scatterplot(PHook~THook, box=F,smooth=F,ForbHook)

plot(predict(modelH),rstandard(modelH))
abline(h=c(-2,0,2),lty=2)




# Modelem logP vs T. Forbes

plot(ForbHook$TForb,log(ForbHook$PForb))

modelLGPFN = lm(log(PForb)~TForb, ForbHook)
summary(modelLGPFN)

scatterplot(log(PForb)~TForb, box=F,smooth=F,ForbHook)

plot(predict(modelLGPFN),rstandard(modelLGPFN))
abline(h=c(-2,0,2),lty=2)

qqnorm(rstandard(modelLGPFN))



# Modelem logP vs T. Hooker

plot(ForbHook$THook,log(ForbHook$PHook))

modelLGPH = lm(log(PHook)~THook, ForbHook)
summary(modelLGPH)

scatterplot(log(PHook)~THook, box=F,smooth=F,ForbHook)

plot(predict(modelLGPH),rstandard(modelLGPH))
abline(h=c(-2,0,2),lty=2)

qqnorm(rstandard(modelLGPH))







# Ajust del model logP vs T a les dues mostres a 
# l'hora per veure si hi ha diferencia entre el model
# per les dades de Forbes, i el model per les dades de Hooker.

Forbes = cbind(ForbHook$PForb,ForbHook$TForb,1)
Hooker = cbind(ForbHook$PHook,ForbHook$THook,0)
FH = rbind.data.frame(Hooker,Forbes)
colnames(FH) = c("P","T","Ind")
FH

plot(FH$T,log(FH$P), col=as.integer(FH$Ind+2))


# Ajust model no additiu, amb interaccio. Dues rectes qualsevols
modelLPTNA = lm(log(P)~ T*Ind,FH)
# Es equivalent a modelLPTNA = lm(log(P)~T+Ind+T:Ind,FH)
summary(modelLPTNA)

plot(predict(modelLPTNA),rstandard(modelLPTNA),col=as.integer(FH$Ind+2))
abline(h=c(-2,0,2),lty=2)



# Ajust model additiu, sense interaccions. Dues rectes paral.leles 
modelLPTA = lm(log(P)~ T + Ind,FH)
summary(modelLPTA)



# Ajust de la mateixa recta als dos grups, Forbes i Hooker 
modelLPT = lm(log(P)~ T,FH)
summary(modelLPT)



anova(modelLPTA,modelLPTNA)

anova(modelLPT,modelLPTNA)


# Ens quedem amb el modelLPT. Les rectes per els dos grups son iguals,
# (com era d'esperar que sortiria)


