library(car)

Wd = read.csv2("Wood0.csv")
head(Wd)

pairs(~Volume+Diameter+Height,Wd)



# Model Vol versus Diam i Height

modelVDH = lm(Volume~Diameter+Height, Wd)
summary(modelVDH)

plot(predict(modelVDH),rstandard(modelVDH))
abline(h=c(-2,0,2),lty=2)

qqnorm(rstandard(modelVDH))



# Model logVol versus logDiam + logHeight

modelLVLDLH = lm(log(Volume)~log(Diameter)+log(Height), Wd)
summary(modelLVLDLH)

plot(predict(modelLVLDLH),rstandard(modelLVLDLH))
abline(h=c(-2,0,2),lty=2)

#qqnorm(rstandard(modelLVLDLH))



# Model Vol versus Diam^2*Height

Wd$d2h = (Wd$Diameter^2)*Wd$Height
modelVCil = lm(Volume~d2h, Wd)
summary(modelVCil)

plot(predict(modelVCil),rstandard(modelVCil))
abline(h=c(-2,0,2),lty=2)

#qqnorm(rstandard(modelVCil))
