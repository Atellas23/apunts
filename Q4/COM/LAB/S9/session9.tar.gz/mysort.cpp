#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

int check_equal (std::vector<float> & v)
{
   int num = 0;
   int i, j;
   for (i=0; i < (v.size()-1); i++) 
      for (j=i+1; j < (v.size()-1); j++)
         if(v[i] == v[j]) num++;
   
   return num;
}

bool check_sorted (std::vector<float> & v)
{
   int i;
   bool ok = true;
   for (i=0; ok && (i < (v.size()-1)); i++)
#ifdef CHECKING
      if (v[i] != v[i+1]) {
#endif
         if (v[i] > v[i+1]) ok = false;
#ifdef CHECKING
      }
      else std::cout << "Sorting is suspicious!!!" << std::endl;
#endif
   return ok;
}

void write_vector(std::vector<float> & v, int l, int h)
{
   int i;
#ifdef DEBUG
   std::cout << "merge " << l <<':'<< h << ": ";
#endif
   for(i=l; i < h; i++)
      std::cout << v[i] << ' ';
   std::cout << std::endl;
}

void mymerge(std::vector<float> & v, int l, int m, int h)
{
   int i, j, om = m;
   float tmp = v[l];

   for (i=l; (i<m) && (m<h); i++) {
      if (tmp <= v[m]) {
         v[i] = tmp;
         tmp = v[i+1]; 
      }
      else             { 
         v[i] = v[m];
         for (j = m++; j > (i+1); j--) {
            v[j] = v[j-1];
         }
         if ((i+1) < m) v[i+1] = tmp;
      }
#ifdef DEBUG
      std::cout << std::endl << i << ' ' << tmp << ", "; write_vector (v, l, h);
#endif
   }
#ifdef DEBUG
   std::cout << "tmp at exit " << tmp << std::endl;
#endif
}

void write_vector(std::vector<float> & v, int l, int m, int h)
{
   int i;
#ifdef DEBUG
   std::cout << "merge " << l <<':' << m <<':' << h << ": ";
#endif
   for(i=l; i < h; i++)
      std::cout << v[i] << ' ';
   std::cout << std::endl;
}

void mysort (std::vector<float> & v, int l, int h)
{
   int m;
   m = l + (h-l) / 2;
#ifdef DEBUG
   std::cout << "sort  : " << l << ' ' << m << ' ' << h << std::endl;
#endif
   if ((h-l) == 1) return;
   else if ((h-l) == 2) {
      if (v[l] > v[h-1]) {
         float tmp = v[h-1];
         v[h-1] = v[l];
         v[l] = tmp;
      }
   }
   else {
      mysort(v, l, m);
      mysort(v, m, h);
#ifdef DEBUG
      write_vector(v, l, m, h);
#endif
      mymerge(v, l, m, h);
#ifdef DEBUG
      write_vector(v, l, m, h);
#endif
   }
}

void write_vector(std::vector<float> & v)
{
   int i;
   std::cout << "sort  " << 0 <<':'<< v.size() << ": ";
   for(i=0; i < v.size(); i++)
      std::cout << v[i] << ' ';
   std::cout << std::endl;
}


int main(int argc, char * argv[])
{
   bool correct;
   int i, size;
   std::vector<float> v;

   std::srand(std::time(NULL)); // use current time as seed for random generator
   int random_variable = std::rand();

   if (argc!=2) {
      std::cerr << "Us: " << argv[0] << " <how-many-numbers>" << std::endl;
      exit(1);
   }

   size = atoi(argv[1]);

   for (i=0; i < size; i++) {
       v.push_back((float) random_variable / (float) (RAND_MAX) * 10.0f);
       random_variable = std::rand();
   }

#ifdef PRINT_VECTOR
   write_vector(v);
#endif
#ifdef CHECKING
   i = check_equal(v);
   if (i > 0) std::cout << "There are " << i << std::endl;
#endif

   mysort(v, 0, v.size());

   correct = check_sorted(v);
#ifdef PRINT_VECTOR
   write_vector(v);
#endif
   if (correct) 
      std::cout << "Sorting is correct!!!" << std::endl;
   else
      std::cout << "Incorrect sorting!!!" << std::endl;

   return 0;
}
