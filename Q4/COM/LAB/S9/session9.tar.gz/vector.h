void init_vector (float *, int);
void add_to_vector (float *, int, float);
