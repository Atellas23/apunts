#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#include "vector.h"

#define N 1000000

float vector[N];

void zero_vector(float * v, int size)
{
   int i; 
   for (i=0; i < size; i++) vector[i] = 0.0f;
}

int main()
{
 char message[1024];
 int pid, i, res;

sleep(5);

 zero_vector(vector, N);
 init_vector(vector, N);

 for(i=0; i < 3; i++) {
   pid = fork();
   if (pid==0) {
      sprintf(message, "child (%d): Hello, World\n", getpid());
      puts(message);
      add_to_vector(vector, N, 10.0);
      sprintf(message, "child (%d): value %f\n", getpid(), vector[N-1]);
      puts(message);
      exit(0);
   }
   else if (pid > 0) {
      sprintf(message, "parent: Hello, World\n");
      puts(message);
      add_to_vector(vector, N, 5.0);
      res = waitpid(pid, NULL, 0);
      if (res < 0) perror ("waitpid");
      sprintf(message, "parent: value %f\n", getpid(), vector[N-1]);
      puts(message);
   }
   else perror ("fork");
 
   sleep(1);
 }

return 0;
}

