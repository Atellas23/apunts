#include <stdio.h>
#include <math.h>

void init_vector (float * vector, int size)
{
 int i;

 for(i=0; i < size; i++) {
   vector[i] = (float) (i+1);
 }
}

void add_to_vector (float * vector, int size, float v)
{
 int i;

 for(i=0; i < size; i++) {
   vector[i] += v;
 }
}
