#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main (int argc, char * argv [])
{
   pid_t pid;
   int res;


   pid = fork();

    //       -------
    //       |child|
    //       --- ---
    //         |a| channel commpipe[1]  XXXcommpipe[0]
    //         |l|     |                   ^
    //         |o|     |                   |
    //         |h|     v                   |
    //         | |
    //         | | channel commpipe[0]  XXXcommpipe[1]
    //       --- ---
    //      |parent |
    //       -------





   int status = 0;
   res = waitpid(pid,&status,0);
   if (res >= 0) {
      printf ("Child process ended with status: %d\n", WEXITSTATUS(status));
   } 
   else 
      perror ("waitpid");

   return 0;
}

