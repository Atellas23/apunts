#!/bin/bash

do_work=1
delay=1.0

if [ x$1 == x-h ]; then
   echo Us: $0 '[ps-process-selection-options] | -h | --help'
   echo '  process selection: -e              all processes'
   echo '                     -u <username>   all processes running as user'
   echo '                     -t <pts/N>      all processes running in tty'
   echo '  while running:  q   quits'
   echo '                  s   reads new delay between updates'
   do_work=0
fi
if [ x$1 == x--help ]; then
   echo Us: $0 '[ps-process-selection-options] | -h | --help' 
   echo '  process selection: -e              all processes'
   echo '                     -u <username>   all processes running as user'
   echo '                     -t <pts/N>      all processes running in tty'
   echo '  while running:  q   quits'
   echo '                  s   reads new delay between updates'
   do_work=0
fi

if [ x$1 == x ]; then
   psopt=
else
   psopt="$*"
fi

while [ $do_work == 1 ]; do
  processes=`ps $psopt -o pid`

  #clear
  echo -n -e "\x1b\x5b\x48\x1b\x5b\x32\x4a\x1b\x5b\x33\x4a"
  echo "  PID   COMM     USER   S    fdlist"
  for proc in $processes ; do
     user=`ls -ld /proc/$$ | awk '{ print $3; }'`
     if [ -f /proc/$proc/status ]; then
      echo "`(echo -n $proc; echo -n '            ') | cut -b -7`" "`(head -1 /proc/$proc/status 2>/dev/null | sed 's/$/          /'| cut -b 1-) | cut -b 7-15`" "$user" "`head -3 /proc/$proc/status 2>/dev/null | tail -1 | cut -b 8`" "" `ls -lU /proc/$proc/fd 2>/dev/null | grep -v "total 0" | awk ' { if (length ($9) < 3) { printf("(%s)%s ", $9, $11); } }'`
     fi
  done
  read -t $delay -s -N 1 ANS
  if [ x$ANS == xq ]; then
    do_work=0;
  elif [ x$ANS == xs ]; then
    echo 
    read -p "Change delay from $delay to: " delay
  fi

done
