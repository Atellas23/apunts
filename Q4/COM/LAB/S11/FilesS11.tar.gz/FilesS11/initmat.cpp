#include <stdio.h>
#include <sys/time.h>
#include <malloc.h>
#include <cmath>

#define SIZE 10240
#define TYPE float
// activate for row-wise accesses
#define ACCESS(i,j) (((i)*SIZE)+(j))
// acivate for column-wise accesses
//#define ACCESS(i,j) (((j)*SIZE)+(i))

int main(int argc, char * argv [])
{
   TYPE * mat = (TYPE *)malloc(SIZE*SIZE*sizeof(TYPE));
   int loop, res, i, j;
   struct timeval tv0, tv1;

   if (mat == NULL) {
      perror ("malloc");
      return 1;
   }

 for (loop = 0; loop < 5; loop++) {
   res = gettimeofday(&tv0, NULL);
   if (res < 0) perror("gettimeofday");
   for (i=0; i < SIZE; i++) {
      for (j=0; j < SIZE; j++) {
         mat[ACCESS(i,j)] = (TYPE) (1+i*j);
      }
   }
   res = gettimeofday(&tv1, NULL);
   if (res < 0) perror("gettimeofday");
   fprintf (stderr, "ini: %lf us\n", 
      tv1.tv_sec*1000000.0 + tv1.tv_usec -
      tv0.tv_sec*1000000.0 - tv0.tv_usec);
 }
 return 0;
}
